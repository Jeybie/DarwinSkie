# Hotel-Reservation-System

The program reads in a file that contains customers' preferences for rooms and then the program looks 
through its database to find a matching room. If the customer requires consecutive rooms fo a particular type then the program will search for unallocated rooms. If there are any left then the program will reserve them otherwise look for other types of room. 
